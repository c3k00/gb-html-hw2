def create_packing_dict(friends):
    packing_dict = {}
    for friend, items in friends.items():
        packing_dict[friend] = set(items)  # Преобразуем список во множество
    return packing_dict

# Пример использования:
friends_items = {
    "Анна": ["палатка", "спальник", "фонарик"],
    "Борис": ["палатка", "еда", "перчатки"],
    "Виктор": ["палатка", "спальник", "еда", "фонарик"]
}

packing_dict = create_packing_dict(friends_items)

# Выводим результат
print("Словарь с вещами друзей:")
for friend, items in packing_dict.items():
    print(f"{friend}: {items}")

###
common_items = set.intersection(*packing_dict.values())
print("Вещи, взятые всеми друзьями:", common_items)
###
unique_items = set.union(*packing_dict.values()) - common_items
print("Уникальные вещи:", unique_items)
###
for friend, items in packing_dict.items():
    missing_items = common_items - set(items)
    if missing_items:
        print(f"{friend} не взял(а) следующие вещи:", missing_items)
