# ✔ Три друга взяли вещи в поход. Сформируйте
# словарь, где ключ — имя друга, а значение —
# кортеж вещей. Ответьте на вопросы:
# ✔ Какие вещи взяли все три друга
# ✔ Какие вещи уникальны, есть только у одного друга
# ✔ Какие вещи есть у всех друзей кроме одного
# и имя того, у кого данная вещь отсутствует
# ✔ Для решения используйте операции
# с множествами. Код должен расширяться
# на любое большее количество друзей.
friends = {
    'Максим': ('топор', 'вода', 'еда', 'палатка'),
    'Шамиль': ('топор', 'вода', 'закуска', 'карты'),
    'Сергей': ('топор', 'водка', 'еда', 'карты')
}


all_things = set()
for friend_item in friends.values():
    all_things.update(set(friend_item))

have_all_friends = all_things.copy()
for friend_item in friends.values():
    have_all_friends.intersection_update(friend_item)
print('Вещи, которые есть у всех:')
print(*have_all_friends)
print()

only_one_friend = {}
for friend in friends:
    friend_backpack = set(friends[friend])
    for other_friend in friends:
        if friend != other_friend:
            friend_backpack.difference_update(friends[other_friend])
    if friend_backpack:
        only_one_friend[friend] = friend_backpack
print('Есть только у одного:', *[f'{name}: {", ".join(back)}' for name, back in only_one_friend.items()], sep='\n')
print()

all_except_one_friend = {}
for friend in friends:
    friend_backpack = friends[friend]
    friends_backpacks = all_things.copy()
    for other_friend in friends:
        if friend != other_friend:
            friends_backpacks.intersection_update(friends[other_friend])
    friends_backpacks.difference_update(friend_backpack)
    if friends_backpacks:
        all_except_one_friend[friend] = friends_backpacks
print('Есть у всех, кроме одного:', *[f'{name} не взял: {", ".join(back)}' for name, back in all_except_one_friend.items()], sep='\n')