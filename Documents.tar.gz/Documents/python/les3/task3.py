# ✔ Создайте вручную список с повторяющимися элементами.
# ✔ Удалите из него все элементы, которые встречаются дважды.
# def remove_duplicates_short(input_list):
#     return list(set(input_list))

# original_list = [1, 2, 2, 3, 3, 4, 4, 5]
# unique_list = remove_duplicates_short(original_list)
# print("Уникальные элементы:", unique_list)

def remove_duplicates_long(input_list):
    new_list = []
    [new_list.append(x) for x in input_list if x not in new_list]
    return new_list

original_list = [1, 2, 2, 3, 3, 4, 4, 5]
unique_list = remove_duplicates_long(original_list)
print("Уникальные элементы:", unique_list)

# Конечно! Давайте разберем подробнее код, который я предложил для удаления повторяющихся элементов из списка.

# 1. **Создание списка с повторяющимися элементами**:
#    В начале мы создаем список `my_list`, который содержит дубликаты элементов:

#     ```python
#     my_list = [1, 2, 2, 3, 3, 4, 4, 5]
#     ```

#    В данном примере `my_list` включает следующие элементы:
#    - `1`
#    - `2`
#    - `2`
#    - `3`
#    - `3`
#    - `4`
#    - `4`
#    - `5`

# 2. **Удаление повторяющихся элементов**:
#    Существует два способа удаления дубликатов из списка:

#     - **Использование множества (set)**:
#       Мы можем преобразовать список во множество, а затем обратно в список, чтобы удалить дубликаты. Однако при этом мы потеряем порядок элементов:

#         ```python
#         def remove_duplicates_short(input_list):
#             return list(set(input_list))

#         original_list = [1, 2, 2, 3, 3, 4, 4, 5]
#         unique_list = remove_duplicates_short(original_list)
#         print("Уникальные элементы:", unique_list)
#         ```

#       В этом коде:
#       - `set(input_list)` создает множество из элементов списка `input_list`.
#       - `list(...)` преобразует множество обратно в список.

#     - **Использование list comprehension**:
#       Мы можем создать новый список, добавляя элементы только в том случае, если они еще не встречались:

#         ```python
#         def remove_duplicates_long(input_list):
#             new_list = []
#             [new_list.append(x) for x in input_list if x not in new_list]
#             return new_list

#         original_list = [1, 2, 2, 3, 3, 4, 4, 5]
#         unique_list = remove_duplicates_long(original_list)
#         print("Уникальные элементы:", unique_list)
#         ```

#       В этом коде:
#       - Мы создаем пустой список `new_list`, который будет содержать уникальные элементы.
#       - С помощью list comprehension мы проходим по элементам `input_list`.
#       - Если элемент еще не встречался в `new_list`, мы добавляем его в список.

#    Оба эти метода позволяют получить новый список, содержащий только уникальные элементы исходного списка. 
# Выберите тот, который вам больше нравится!

# numbers = [1, 2, 3, 2, 1, 5, 6, 5, 5, 5]
# li = []
# for i in numbers:
#   if i not in li:
#     li.append(i)

# print (li)