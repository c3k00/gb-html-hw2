# ✔ Функция получает на вход строку из двух чисел через пробел.
# ✔ Сформируйте словарь, где ключом будет
# символ из Unicode, а значением — целое число.
# ✔ Диапазон пар ключ-значение от наименьшего из введённых
# пользователем чисел до наибольшего включительно.

def create_unicode_dict(input_str):
    # Разбиваем строку на числа
    num1, num2 = map(int, input_str.split())
    
    # Находим наименьшее и наибольшее число
    start = min(num1, num2)
    end = max(num1, num2)
    
    # Создаем словарь
    unicode_dict = {}
    for code in range(start, end + 1):
        unicode_dict[chr(code)] = code
    
    return unicode_dict

# Пример использования
input_str = input("Введите два числа через пробел: ")
result = create_unicode_dict(input_str)
print(result)