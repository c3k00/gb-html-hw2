# ✔ Функция получает на вход список чисел и два индекса.
# ✔ Вернуть сумму чисел между между переданными индексами.
# ✔ Если индекс выходит за пределы списка, сумма считается
# до конца и/или начала списка.
def sum_between_indices(lst, start_index, end_index):
    # Определяем границы суммирования
    start = max(0, min(start_index, len(lst) - 1))
    end = max(0, min(end_index, len(lst) - 1))
    
    # Определяем направление суммирования
    if start < end:
        result = sum(lst[start:end+1])
    else:
        result = sum(lst[end:start+1])
    
    return result

# Примеры использования
print(sum_between_indices([1, 2, 3, 4, 5], 0, 3))  # Вывод: 10
print(sum_between_indices([1, 2, 3, 4, 5], 2, 4))  # Вывод: 12
print(sum_between_indices([1, 2, 3, 4, 5], -3, -1))  # Вывод: 7
print(sum_between_indices([1, 2, 3, 4, 5], 5, 2))  # Вывод: 9
print(sum_between_indices([1, 2, 3, 4, 5], 6, 7))  # Вывод: 0