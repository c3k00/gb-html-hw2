def str_text(text):

    cod = sorted(set(ord(i) for i in text), reverse=True)
    return cod


text = "Всем привет кто смотрит респект"
print(str_text(text))