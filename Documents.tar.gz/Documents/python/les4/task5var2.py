def prizes(names: list, moneys: list, bonuses: list) -> dict:
    return {nam: money * float(bonus[:-1]) * 0.01 for nam, money, bonus in zip(names, moneys, bonuses)}