# ✔ Напишите функцию, которая принимает строку текста.
# ✔ Сформируйте список с уникальными кодами Unicode каждого
# символа введённой строки отсортированный по убыванию.

def get_sorted_unicode_codes(text):
    # Получаем список уникальных кодов Unicode символов из строки
    unicode_codes = list(set(ord(char) for char in text))
    
    # Сортируем список кодов по убыванию
    sorted_codes = sorted(unicode_codes, reverse=True)
    
    return sorted_codes

# Пример использования
text = "Hello, World!"
sorted_unicode_codes = get_sorted_unicode_codes(text)
print(sorted_unicode_codes)