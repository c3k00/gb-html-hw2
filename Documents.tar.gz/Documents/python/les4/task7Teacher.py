def check_profit(data: dict) -> bool:
    for values in data.values():
        if sum(values[0]) < sum(values[1]):
            return False
    return True
