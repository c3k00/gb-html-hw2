# ✔ Функция принимает на вход три списка одинаковой длины:
# ✔ имена str,
# ✔ ставка int,
# ✔ премия str с указанием процентов вида «10.25%».
# ✔ Вернуть словарь с именем в качестве ключа и суммой
# премии в качестве значения.
# ✔ Сумма рассчитывается как ставка умноженная на процент премии.

def calculate_bonuses(names, salaries, bonus_percentages):
    bonuses = {}
    
    for name, salary, bonus_percentage in zip(names, salaries, bonus_percentages):
        # Извлекаем процент премии из строки
        bonus_percent = float(bonus_percentage.strip('%')) / 100
        
        # Вычисляем сумму премии
        bonus_amount = salary * bonus_percent
        
        # Добавляем в словарь
        bonuses[name] = bonus_amount
    
    return bonuses

# Пример использования
names = ['John', 'Jane', 'Bob']
salaries = [5000, 6000, 4500]
bonus_percentages = ['10.5%', '12%', '8.75%']

bonuses = calculate_bonuses(names, salaries, bonus_percentages)
print(bonuses)