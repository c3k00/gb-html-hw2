# ✔ Напишите функцию, которая принимает строку текста.
# Вывести функцией каждое слово с новой строки.
# ✔ Строки нумеруются начиная с единицы.
# ✔ Слова выводятся отсортированными согласно кодировки Unicode.
# ✔ Текст выравнивается по правому краю так, чтобы у самого
# длинного слова был один пробел между ним и номером строки.

def print_words_numbered(text):
    # Разбиваем текст на слова
    words = text.split()
    
    # Сортируем слова по кодировке Unicode
    sorted_words = sorted(words, key=lambda x: [ord(c) for c in x])
    
    # Находим длину самого длинного слова
    max_word_length = len(max(sorted_words, key=len))
    
    # Выводим слова с новой строки, нумеруя строки и выравнивая слова по правому краю
    for i, word in enumerate(sorted_words, start=1):
        print(str(i).rjust(len(str(len(sorted_words)))) + ' ' + word.rjust(max_word_length + 1))

# Пример использования
text = "The quick brown fox jumps over the lazy dog"
print_words_numbered(text)