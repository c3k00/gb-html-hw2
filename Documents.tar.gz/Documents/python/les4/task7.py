# ✔ Функция получает на вход словарь с названием компании в качестве ключа
# и списком с доходами и расходами (3-10 чисел) в качестве значения.
# ✔ Вычислите итоговую прибыль или убыток каждой компании. Если все компании
# прибыльные, верните истину, а если хотя бы одна убыточная — ложь.

# my_dict = {"Яндекс": ([50, 10, 20], [1, 100, 5, 8]), "Google": ([20, 18, 55], [8, 14, 17]),
#            "Mail": ([80, 51, 13], [7, 16, 20]), "Вконтакте": ([17, 46, 20, 55], [13, 18, 77])}

# def all_companies_profitable(companies):
#     for company, (income, expenses) in companies.items():
#         total_income = sum(income)
#         total_expenses = sum(expenses)
#         profit = total_income - total_expenses
        
#         if profit < 0:
#             return False
    
#     return True

# # Пример использования
# my_dict = {"Яндекс": ([50, 10, 20], [1, 100, 5, 8]), "Google": ([20, 18, 55], [8, 14, 17]),
#            "Mail": ([80, 51, 13], [7, 16, 20]), "Вконтакте": ([17, 46, 20, 55], [13, 18, 77])}

# result = all_companies_profitable(my_dict)
# print(result)

# Определение словаря с доходами и расходами компаний
company_finances = {
    "Яндекс": ([50, 10, 20], [1, 100, 5, 8]),
    "Google": ([20, 18, 55], [8, 14, 17]),
    "Mail": ([80, 51, 13], [7, 16, 20]),
    "Вконтакте": ([17, 46, 20, 55], [13, 18, 77])
}

# Функция для вычисления прибыли или убытка каждой компании
def calculate_profit_or_loss(finances):
    results = {}
    all_profitable = True
    for company, (revenues, expenses) in finances.items():
        profit = sum(revenues) - sum(expenses)
        results[company] = profit
        if profit < 0:
            all_profitable = False
    return results, all_profitable

# Вычисление и вывод результатов
profits, all_profitable = calculate_profit_or_loss(company_finances)
for company, profit in profits.items():
    print(f"{company}: {'Прибыль' if profit > 0 else 'Убыток'} в размере {profit}")

print(f"Все компании прибыльные: {'Истина' if all_profitable else 'Ложь'}")
