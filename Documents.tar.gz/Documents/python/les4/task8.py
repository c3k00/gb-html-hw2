numbers = 123
text = "123123"
names = "Андрей"
s = "Python"


numbers = None
number = 123
text = "123123"
names = None
name = "Андрей"
s = "Python"

def rename_variable():
    temp = {}
    for key, value in globals().items():
        if key.endswith('s') and len(key) > 1:
            temp[key[:-1]] = value
            temp[key] = None
    print(temp)
    globals().update(temp)