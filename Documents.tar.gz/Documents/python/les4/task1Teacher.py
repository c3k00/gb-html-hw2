def func_string(srtn: str):
    strn = sorted(srtn.lower().split())
    max_len = len(max(strn, key=len))
    for num, word in enumerate(strn,1):
        print(f"{num} {word:>{max_len}}")


func_string("Напишите функцию которая принимает строку текста")