# Создайте класс Моя Строка, где:
# будут доступны все возможности str
# дополнительно хранятся имя автора строки и время создания
# (time.time)

# import time

# class МояСтрока(str):
#     def __new__(cls, значение, автор):
#         # Создаем новый экземпляр МояСтрока
#         экземпляр = super().__new__(cls, значение)
#         # Устанавливаем дополнительные атрибуты
#         экземпляр.автор = автор
#         экземпляр.время_создания = time.time()
#         return экземпляр

# # Пример использования
# моя_строка = МояСтрока("Привет, мир!", автор="Иван")
# print(f"Значение: {моя_строка}")
# print(f"Автор: {моя_строка.автор}")
# print(f"Время создания: {моя_строка.время_создания}")

import time
import datetime
class MyString(str):
    def __new__(cls, string,author=None):
        data = super().__new__(cls,string)
        data.author = author
        data.time = time.time()
        data.time_new = datetime.datetime.now()
        return data

my_string = MyString('Рок н ролл',author='Stoun')

print(my_string)
print(my_string.author)
print(my_string.time)
print(my_string.time_new)