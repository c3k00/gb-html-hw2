# Добавьте к задачам 1 и 2 строки документации для классов.

class Archive:
    arch = []

    def __init__(self, number, letter):
        Archive.arch.append([number, letter])
        self.number = number
        self.letter = letter

    def __str__(self):
        return f'STR: {self.number} {self.letter}'

    def __repr__(self):
        return f'REPR: {self.number} {self.letter}'


a = Archive(1, 'a')
b = Archive(2, 'b')

print(a.__repr__())
print(b)
c = [a,b]
print(str(c))