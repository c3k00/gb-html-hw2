# Напишите функцию, которая сохраняет созданный в
# прошлом задании файл в формате CSV.

import json
import csv

def convert_to_csv(json_file, csv_file):
    with (
        open(json_file, 'r', encoding='UTF-8') as users_json,
        open(csv_file, 'w', encoding='UTF-8', newline='') as users_csv
    ):
        data = json.load(users_json)
        csv_writer = csv.writer(users_csv)
        csv_writer.writerow(['name', 'ID', 'level'])

        for user_lvl, users in data.items():
            for user_id, user_name in users.items():
                csv_writer.writerow([user_name, user_id, user_lvl])

convert_to_csv('task_2_2.json', 'task_3_2.csv')