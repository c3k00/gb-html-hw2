# Напишите функцию, которая преобразует pickle файл
# хранящий список словарей в табличный csv файл.
# Для тестированию возьмите pickle версию файла из задачи
# 4 этого семинара.
# Функция должна извлекать ключи словаря для заголовков
# столбца из переданного файла.
import csv
import pickle
import os
def pickle_to_csv(path_pickle: str, headers: list[str]):
    current_path_pickle = os.path.split(path_pickle)
    path_csv = os.path.join(current_path_pickle[0], current_path_pickle[-1].split('.')[0] + '.csv')
    with(
        open(path_pickle, 'rb') as pickle_file,
        open(path_csv, 'w', encoding='UTF-8') as csv_file
    ):
        data = pickle.load(pickle_file)
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(headers)
        for user_level, user in data.items():
            for user_id, user_name in user.items():
                csv_writer.writerow([user_name, user_id, user_level])


pickle_to_csv('F:\WorkShopPy\my_python_project\\user_list.pickle', ['name', 'id', 'level'])

# def print_pickle(path_csv: str):
#     with open(path_csv, 'r', encoding='UTF-8') as csv_file:
#         csv_reader = csv.reader(csv_file)
#         data = [row for row in csv_reader]
#         print(pickle.dumps(data))

# print_pickle('user_csv.csv')