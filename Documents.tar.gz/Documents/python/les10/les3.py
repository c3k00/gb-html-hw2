# Напишите класс для хранения информации о человеке:
# ФИО, возраст и т.п. на ваш выбор.
# У класса должны быть методы birthday для увеличения
# возраста на год, full_name для вывода полного ФИО и т.п. на
# ваш выбор.
# Убедитесь, что свойство возраст недоступно для прямого
# изменения, но есть возможность получить текущий возраст.

class Human:
    def __init__(self, last_name, second_name, first_name, age):
        self.last_name = last_name
        self.second_name =second_name
        self.first_name = first_name
        self._age = age

    def birthday(self):
        self._age+=1

    def full_name(self):
        return f"Ф.И.О: {self.last_name}, {self.second_name}, {self.first_name} "

    def ages(self):
        return f"Возраст {self._age}"



p = Human("Каширов", "Максим", "Анатольевич", 30)

print(p.ages())
print(p.full_name())
p.birthday()
print(p.ages())