import random
from typing import Callable


def random_number_game(min_number: int, max_number: int, count: int) -> Callable:
    random_number = random.randint(min_number, max_number)
    print(f'Отгадайте число от {min_number} до {max_number}. Попыток {count}')

    def check_random():
        for _ in range(count):
            user = int(input('Введите число: '))
            if user == random_number:
                print('Поздравляем!')
                return
            elif user < random_number:
                print('Загаданное число больше')
            else:
                print('Загаданное число меньше')
        print(f'К сожалению вы исчерпали {count} попыток. Число было {random_number}')

    return check_random


MIN_NUMBER = 1
MAX_NUMBER = 100
COUNT = 5
result = random_number_game(MIN_NUMBER, MAX_NUMBER, COUNT)
result()