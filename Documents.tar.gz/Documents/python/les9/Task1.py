#Создайте функцию-замыкание, которая запрашивает два целых
#числа:
#○ от 1 до 100 для загадывания,
#○ от 1 до 10 для количества попыток
#Функция возвращает функцию, которая через консоль просит
#угадать загаданное число за указанное число попыток.
import random
from typing import Callable
# import compile
def random_number_game(min_number: int, max_number: int, count: int) -> Callable:
    def random_number():
        result_number = random.randint(min_number,max_number)
        print(f'Отгадайте число от {min_number}до {max_number}. попыток {count}')
        def chek_random() -> None:
            for _ in range(count):
                user = int(input('Введитье число '))
                if user == result_number:
                    print('Поздравляем!')
                    return
                elif user < result_number:
                    print('Загаданное число больше ')
                else:
                    print('Загаданное число mеньше ')
            print(f'К сожадению вы изчерпали {count} попыток. число было {result_number}')
        return chek_random
    return random_number

MIN_NUMBER = 1
MAX_NUMBER = 100
COUNT = 5
result = random_number_game(MIN_NUMBER,MAX_NUMBER,COUNT)
start_result = result()
start_result()
