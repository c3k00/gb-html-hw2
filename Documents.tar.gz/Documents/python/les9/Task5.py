# Объедините функции из прошлых задач.
# Функцию угадайку задекорируйте:
# ○ декораторами для сохранения параметров,
# ○ декоратором контроля значений и
# ○ декоратором для многократного запуска.
# Выберите верный порядок декораторов.

import os
import json


def counter(number):
    def outter(func):
        result = []

        def inner(*args, **kwargs):
            for _ in range(number):
                result.append(func(*args, **kwargs))
            return result

        return inner

    return outter


def json_writer(func):
    def wrapper(*args, **kwargs):
        file_name = f'{func.__name__}.json'
        if os.path.exists(file_name):
            with open(file_name, 'r', encoding='UTF-8') as file:
                data_json = json.load(file)
                current_id = int(max(data_json, key=lambda x: int(x))) + 1
        else:
            data_json = {}
            current_id = 1
        result = func(*args, **kwargs)
        data_json[current_id] = {'func_name': func.__name__, 'result': result, 'args': args, 'kwargs': {}}
        for key, value in kwargs.items():
            data_json[current_id]['kwargs'][key] = value
        with open(file_name, 'w', encoding='UTF-8') as file:
            json.dump(data_json, file, indent=4, ensure_ascii=False)

    return wrapper


@counter(5)
@json_writer
def summa_args(*args, **kwargs):
    return sum(map(int, args))


summa_args(1, 2, 8, 8, 9, 78, 90, k='6', l='8', h=78)