# Напишите декоратор, который сохраняет в json файл
# параметры декорируемой функции и результат, который она
# возвращает. При повторном вызове файл должен
# расширяться, а не перезаписываться.
# Каждый ключевой параметр сохраните как отдельный ключ
# json словаря.
# Для декорирования напишите функцию, которая может
# принимать как позиционные, так и ключевые аргументы.
# Имя файла должно совпадать с именем декорируемой
# функции.

import os
import json


def json_writer(func):
    def wrapper(*args, **kwargs):
        file_name = f'{func.__name__}.json'
        if os.path.exists(file_name):
            with open(file_name, 'r', encoding='UTF-8') as file:
                data_json = json.load(file)
                current_id = int(max(data_json)) + 1
        else:
            data_json = {}
            current_id = 1
        result = func(args, kwargs)
        data_json[current_id] = {'func_name': func.__name__, 'result': result, 'args': args, 'kwargs': {}}
        for key, value in kwargs.items():
            data_json[current_id]['kwargs'][key] = value
        with open(file_name, 'w', encoding='UTF-8') as file:
            json.dump(data_json, file, indent=4, ensure_ascii=False)

    return wrapper


@json_writer
def summa_args(*args, **kwargs):
    return sum(args[0])