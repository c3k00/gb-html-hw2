import random

'''
Дорабатываем задачу 1.
Превратите внешнюю функцию в декоратор.
Он должен проверять входят ли переданные в функциюугадайку числа в диапазоны [1, 100] и [1, 10].
Если не входят, вызывать функцию со случайными числами
из диапазонов.
'''


def validator(func):
    def wrapper(num: int, attempts: int) -> None:
        if not 0 < num < 101:
            num = random.randint(1, 100)
        if not 0 < attempts < 11:
            attempts = random.randint(1, 10)
        return func(num, attempts)

    return wrapper


@validator
def guess_num(num: int, attempts: int) -> None:
    for attempt in range(attempts):
        try:
            guess = int(input(f'Введите целое число от 1 до 100 '
                              f'(попытка {attempt + 1} из {attempts}): \n'))
            if guess == num:
                print(f'Вы угадали! Загаданное число - {num}')
                break
            else:
                print(f'Вы не угадали!')
        except ValueError:
            print('Ошибка ввода, необходимо ввести целое число')

    else:
        print(f'Вы проиграли! Загаданное число - {num}')


if __name__ == '__main__':
    guess_num(120, 5)

