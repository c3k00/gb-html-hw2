# ✔ Напишите программу, которая получает целое число и возвращает
# его двоичное, восьмеричное строковое представление.
# ✔ Функции bin и oct используйте для проверки своего
# результата, а не для решения.
# Дополнительно:
# ✔ Попробуйте избежать дублирования кода
# в преобразованиях к разным системам счисления
# ✔ Избегайте магических чисел
# ✔ Добавьте аннотацию типов где это возможно
def decimal_to_binary(number):
    binary_result = ""
    while number > 0:
        remainder = number % 2
        binary_result = str(remainder) + binary_result
        number //= 2
    return binary_result

def decimal_to_oct(number):
    oct_digits = "0123456789ABCDEF"
    oct_result = ""
    while number > 0:
        remainder = number % 8
        oct_result = oct_digits[remainder] + oct_result
        number //= 8
    return oct_result

number_to_convert = 46
binary_result = decimal_to_binary(number_to_convert)
oct_result = decimal_to_oct(number_to_convert)

print(f"Число {number_to_convert} в двоичной системе: {binary_result}")
print(f"Число {number_to_convert} в восьмеричной системе: {oct_result}")
print(bin(number_to_convert))
print(oct(number_to_convert))
