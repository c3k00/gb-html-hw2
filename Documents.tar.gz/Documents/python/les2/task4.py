# Напишите программу, которая вычисляет площадь
# круга и длину окружности по введённому диаметру.
# ✔ Диаметр не превышает 1000 у.е.
# ✔ Точность вычислений должна составлять
# не менее 42 знаков после запятой.
import decimal

def calculate_circle_properties(diameter):
    # Радиус круга
    radius = diameter / 2

    # Вычисление площади круга
    area = decimal.Decimal(decimal.Decimal(radius) ** 2) * decimal.Decimal('3.14159265358979323846264338327950288419716939937510')

    # Вычисление длины окружности
    circumference = decimal.Decimal(diameter) * decimal.Decimal('3.14159265358979323846264338327950288419716939937510')

    return area, circumference

def main():
    try:
        diameter_input = input("Введите диаметр круга (не превышающий 1000): ")
        diameter = decimal.Decimal(diameter_input)

        if diameter <= 0 or diameter > 1000:
            print("Диаметр должен быть положительным числом, не превышающим 1000.")
            return

        area, circumference = calculate_circle_properties(diameter)

        print(f"Площадь круга: {area:.42f}")
        print(f"Длина окружности: {circumference:.42f}")

    except decimal.InvalidOperation:
        print("Некорректный ввод. Пожалуйста, введите число.")

if __name__ == "__main__":
    main()
