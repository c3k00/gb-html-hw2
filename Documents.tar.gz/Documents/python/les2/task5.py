# ✔ Напишите программу, которая решает
# квадратные уравнения даже если
# дискриминант отрицательный.
# ✔ Используйте комплексные числа
# для извлечения квадратного корня.
import cmath

def solve_quadratic(a, b, c):
    # Вычисляем дискриминант
    discriminant = b**2 - 4*a*c

    # Вычисляем корни
    root1 = (-b + cmath.sqrt(discriminant)) / (2*a)
    root2 = (-b - cmath.sqrt(discriminant)) / (2*a)

    return root1, root2

def main():
    try:
        a = float(input("Введите коэффициент a: "))
        b = float(input("Введите коэффициент b: "))
        c = float(input("Введите коэффициент c: "))

        root1, root2 = solve_quadratic(a, b, c)

        print(f"Первый корень: {root1:.4f}")
        print(f"Второй корень: {root2:.4f}")

    except ValueError:
        print("Некорректный ввод. Пожалуйста, введите числа.")

if __name__ == "__main__":
    main()
