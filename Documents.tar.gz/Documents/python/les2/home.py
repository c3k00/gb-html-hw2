# Напишите программу банкомат.
# ✔ Начальная сумма равна нулю
# ✔ Допустимые действия: пополнить, снять, выйти
# ✔ Сумма пополнения и снятия кратны 50 у.е.
# ✔ Процент за снятие — 1.5% от суммы снятия, но не менее 30 и не более 600 у.е.
# ✔ После каждой третей операции пополнения или снятия начисляются проценты - 3%
# ✔ Нельзя снять больше, чем на счёте
# ✔ При превышении суммы в 5 млн, вычитать налог на богатство 10% перед каждой
# операцией, даже ошибочной
# ✔ Любое действие выводит сумму денег

class ATM:
    def __init__(self):
        self.balance = 0
        self.transactions = 0
        self.total_withdrawals = 0

    def deposit(self, amount):
        if amount % 50 != 0:
            print("Сумма пополнения должна быть кратной 50 у.е.")
            return
        self.balance += amount
        self.transactions += 1
        self.apply_interest()

    def withdraw(self, amount):
        if amount % 50 != 0:
            print("Сумма снятия должна быть кратной 50 у.е.")
            return
        if amount > self.balance:
            print("Недостаточно средств на счете.")
            return
        withdrawal_fee = max(30, min(0.015 * amount, 600))
        self.balance -= (amount + withdrawal_fee)
        self.total_withdrawals += amount
        self.transactions += 1
        self.apply_interest()

    def apply_interest(self):
        if self.transactions % 3 == 0:
            self.balance *= 0.97  # 3% процент после каждой третьей операции

    def apply_wealth_tax(self):
        if self.balance > 5_000_000:
            wealth_tax = 0.10 * self.balance
            self.balance -= wealth_tax

    def display_balance(self):
        print(f"Текущий баланс: {self.balance:.2f} у.е.")

def main():
    atm = ATM()
    while True:
        print("\nВыберите действие:")
        print("1. Пополнить счет")
        print("2. Снять средства")
        print("3. Выйти")
        choice = input("Введите номер действия: ")

        if choice == "1":
            amount = float(input("Введите сумму для пополнения: "))
            atm.deposit(amount)
        elif choice == "2":
            amount = float(input("Введите сумму для снятия: "))
            atm.withdraw(amount)
        elif choice == "3":
            break
        else:
            print("Некорректный выбор. Пожалуйста, введите 1, 2 или 3.")

        atm.apply_wealth_tax()
        atm.display_balance()

if __name__ == "__main__":
    main()
