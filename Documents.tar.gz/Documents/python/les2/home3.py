import sqlite3

class ATM:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()
        self.admin_password = 'root'  # Секретный пароль администратора

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS accounts (
                card_number TEXT PRIMARY KEY,
                balance REAL,
                last_withdrawal REAL
            )
        ''')
        self.conn.commit()

    def deposit(self, card_number, amount):
        self.cursor.execute('''
            INSERT OR REPLACE INTO accounts (card_number, balance, last_withdrawal)
            VALUES (?, COALESCE((SELECT balance FROM accounts WHERE card_number = ?), 0) + ?, NULL)
        ''', (card_number, card_number, amount))
        self.conn.commit()

    def withdraw(self, card_number, amount):
        self.cursor.execute('''
            UPDATE accounts
            SET balance = balance - ?, last_withdrawal = ?
            WHERE card_number = ?
        ''', (amount, amount, card_number))
        self.conn.commit()

    def display_balance(self, card_number):
        self.cursor.execute('SELECT balance FROM accounts WHERE card_number = ?', (card_number,))
        result = self.cursor.fetchone()
        if result:
            print(f"Текущий баланс карты {card_number}: {result[0]:.2f} у.е.")
        else:
            print(f"Карта {card_number} не найдена.")

    def close(self):
        self.conn.close()

# def main():
#     db_file = 'atm_database.db'
#     atm = ATM(db_file)
#     atm.create_table()

#     while True:
#         print("\nВыберите действие:")
#         print("1. Пополнить счет")
#         print("2. Снять средства")
#         print("3. Войти как администратор")
#         print("4. Выйти")
#         choice = input("Введите номер действия: ")

#         if choice == "1":
#             card_number = input("Введите номер карты: ")
#             amount = float(input("Введите сумму для пополнения: "))
#             atm.deposit(card_number, amount)
#         elif choice == "2":
#             card_number = input("Введите номер карты: ")
#             amount = float(input("Введите сумму для снятия: "))
#             atm.withdraw(card_number, amount)
#         elif choice == "3":
#             password = input("Введите пароль администратора: ")
#             if password == atm.admin_password:
#                 card_number = input("Введите новый номер карты: ")
#                 amount = float(input("Введите начальный баланс: "))
#                 atm.deposit(card_number, amount)
#             else:
#                 print("Неверный пароль администратора.")
#         elif choice == "4":
#             break
#         else:
#             print("Некорректный выбор. Пожалуйста, введите 1, 2, 3 или 4.")

#         atm.display_balance(card_number)

#     atm.close()

# if __name__ == "__main__":
#     main()
def main():
    db_file = 'atm_database.db'
    atm = ATM(db_file)
    atm.create_table()

    while True:
        print("\nВыберите действие:")
        print("1. Пополнить счет")
        print("2. Снять средства")
        print("3. Проверить баланс")
       # print("4. Войти как администратор")
        print("4. Выйти")
        choice = input("Введите номер действия: ")

        if choice == "1":
            card_number = input("Введите номер карты: ")
            amount = float(input("Введите сумму для пополнения: "))
            atm.deposit(card_number, amount)
        elif choice == "2":
            card_number = input("Введите номер карты: ")
            amount = float(input("Введите сумму для снятия: "))
            atm.withdraw(card_number, amount)
        elif choice == "3":
            card_number = input("Введите номер карты: ")
            atm.display_balance(card_number)
        elif choice == "root":
            password = input("Введите пароль администратора: ")
            if password == atm.admin_password:
                card_number = input("Введите новый номер карты: ")
                amount = float(input("Введите начальный баланс: "))
                atm.deposit(card_number, amount)
            else:
                print("Неверный пароль администратора.")
        elif choice == "4":
            break
        else:
            print("Некорректный выбор. Пожалуйста, введите 1, 2, 3, или 4.")

    atm.close()

if __name__ == "__main__":
    main()