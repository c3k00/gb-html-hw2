import sys

data = [1,'shamil',3.14,True,-1,'shamil']
for index, value in enumerate(data, 1):
    print(f'порядковый номер:{index}')
    print(f"значение:{value}")
    print(f'адрес в памяти:{id(value)}')
    print((f'размер в памяти:{sys.getsizeof(value)}'))
    print(f'хэш объекта:{hash(value)}')

    if isinstance(value, int) and value > 0:
        print(f'результат проверки на целое число: True')
    else:
        print(f'результат проверки на целое число: False')

    if isinstance(value, str):
        print(f'результат проверки на на строку: True')
    else:
        print(f'результат проверки на на строку: Fals')
    print('\n',"=="*40)