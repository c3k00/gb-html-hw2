# Создайте функцию, которая удаляет из текста все символы
# кроме букв латинского алфавита и пробелов.
# Возвращается строка в нижнем регистре.

# def clean_text(text):
#     cleaned_text = ''.join(char for char in text if char.isalpha() or char.isspace())
#     return cleaned_text.lower()

# from string import ascii_letters


# def not_punctuation(texts):
#     return " ".join(text for text in texts if text in ascii_letters or text == " ")

############################################
# Напишите для задачи 1 тесты doctest. Проверьте
# следующие варианты:
# возврат строки без изменений
# возврат строки с преобразованием регистра без потери
# символов
# возврат строки с удалением знаков пунктуации
# возврат строки с удалением букв других алфавитов
# возврат строки с учётом всех вышеперечисленных пунктов
# (кроме п. 1)

# import unicodedata
# def clean_text(text):
#     """
#     >>> text = ("Hello,Мир!")
#     >>> clean_text("Hello,Мир!")
#     'hello'
#     >>> clean_text("Hello, World!.")
#     'hello world'
#     >>> clean_text("123 456 !@# $%^ &*()  $ ")
#     '       '
#     """
#     data = ''
#     for i in text:
#         if i.isalpha() and unicodedata.name(i).startswith('LATIN'):
#             data += i.lower()
#         elif i.isspace():
#             data += i.lower()
#     return data

# if __name__ == '__main__':
#     import doctest
#     doctest.testmod(verbose=True)

# import unicodedata
# from string import ascii_letters
# def not_punctuation(texts):
#     """
#     >>> not_punctuation("python python")
#     'python python'
#     >>> not_punctuation("Python Python")
#     'python python'
#     >>> not_punctuation("Python, Pyt,hon")
#     'python python'
#     >>> not_punctuation("python Пайтон")
#     'python '
#     >>> not_punctuation("Python, Пайтон/24")
#     'python '
#     """
#     return "".join(text for text in texts if text in ascii_letters or text == " ").lower()



# if __name__ == '__main__':
#     import doctest
#     doctest.testmod(verbose=True)
########################################
# Напишите для задачи 1 тесты unittest. Проверьте
# следующие варианты:
# возврат строки без изменений
# возврат строки с преобразованием регистра без потери
# символов
# возврат строки с удалением знаков пунктуации
# возврат строки с удалением букв других алфавитов
# возврат строки с учётом всех вышеперечисленных пунктов
# (кроме п. 1)

# import unittest

# class TestCaseName(unittest.TestCase):

#     def test_nochanges(self):
#         self.assertEqual('one two', not_punctuation('one two'))

#     def test_up_low(self):
#         self.assertEqual('one two', not_punctuation('ONE two'))

#     def test_punctuation(self):
#         self.assertNotEqual('one, two!', not_punctuation('one, two!'))

#     def test_another_lang(self):
#         self.assertEqual('one two', not_punctuation('one twoцццц'))

#     def test_all_tests(self):
#         self.assertEqual('one two', not_punctuation('ONE twцццo!!!'))


# if __name__ == '__main__':
#     unittest.main(verbosity=2)

############################################

# Напишите для задачи 1 тесты pytest. Проверьте следующие
# варианты:
# возврат строки без изменений
# возврат строки с преобразованием регистра без потери
# символов
# возврат строки с удалением знаков пунктуации
# возврат строки с удалением букв других алфавитов
# возврат строки с учётом всех вышеперечисленных пунктов
# (кроме п. 1)

############################################

# На семинарах по ООП был создан класс прямоугольник
# хранящий длину и ширину, а также вычисляющую периметр,
# площадь и позволяющий складывать и вычитать
# прямоугольники беря за основу периметр.
# Напишите 3-7 тестов unittest для данного класса.

# import unittest

# class Rectangle:
#     def __init__(self, length, width):
#         self.length = length
#         self.width = width

#     def perimeter(self):
#         return 2 * (self.length + self.width)

#     def area(self):
#         return self.length * self.width

#     def __add__(self, other):
#         total_perimeter = self.perimeter() + other.perimeter()
#         new_length = total_perimeter / 4
#         return Rectangle(new_length, self.width)

#     def __sub__(self, other):
#         diff_perimeter = abs(self.perimeter() - other.perimeter())
#         new_length = diff_perimeter / 2
#         return Rectangle(new_length, self.width)
    
#     def __eq__(self, value: object) -> bool:
#         return self.length == value.length and self.width == value.width
    

# class TestCheckRectangle(unittest.TestCase):
#     def setUp(self):
#         self.rect1 = Rectangle(5, 3)
#         self.rect2 = Rectangle(4, 4)
#         self.rect3 = Rectangle(4, 2)

#     def test_perimeter(self):
#         self.assertEqual(self.rect1.perimeter(), self.rect2.perimeter())

#     def test_area(self):
#         self.assertEqual(self.rect1.area(), 15)
#         self.assertEqual(self.rect2.area(), 16)

#     def test_add(self):
#         a = self.rect1 + self.rect2
#         self.assertTrue(a == Rectangle(8, 3))

#     def test_sub(self):
#         b = self.rect1 - self.rect3
#         self.assertTrue(b == Rectangle(2, 3))

# if __name__ == '__main__':
#     unittest.main(verbosity=2)

#############################################

# На семинаре 13 был создан проект по работе с
# пользователями (имя, id, уровень).
# Напишите 3-7 тестов pytest для данного проекта.
# Используйте фикстуры.

