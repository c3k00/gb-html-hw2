# Создайте класс-функцию, который считает факториал числа при
# вызове экземпляра.
# Экземпляр должен запоминать последние k значений.
# Параметр k передаётся при создании экземпляра.
# Добавьте метод для просмотра ранее вызываемых значений и
# их факториалов.

# class Factorial:
#     def __init__(self, k: int) -> None:
#         self.k = k
#         self.history = []

#     def __call__(self, value):
#         result = 1
#         for i in range(1, value + 1):
#             result *= i
#         self.history.append((value, result))
#         self.history = self.history[-self.k:]
#         return result

#     def history(self):
#         return self.history
# variant 2
# class Factorial:
#     def __init__(self) -> None:
#         self.result = 1
#         self.history = {}

#     def __call__(self, value):
#         for i in range(1, value + 1):
#             self.result *= i
#         self.history[value] = self.result
#         return self.result


# num = Factorial()
# print(num(5))
# print(num(7))
# print(num.history)