# Создайте класс-генератор.
# Экземпляр класса должен генерировать факториал числа в
# диапазоне от start до stop с шагом step.
# Если переданы два параметра, считаем step=1.
# Если передан один параметр, также считаем start=1.
# class FactorialGenerator:
#     def __init__(self, start, stop=None, step=None):
#         if stop is None:
#             self.start = 1
#             self.stop = start
#         else:
#             self.start = start
#             self.stop = stop
#         self.step = step if step else 1
#     def factorial(self, n):
#         result = 1
#         for i in range(1, n + 1):
#             result *= i
#         return result
#     def __iter__(self):
#         for num in range(self.start, self.stop + 1, self.step):
#             yield self.factorial(num)

# generator = FactorialGenerator(7,)
# f_l = [i for i in generator]
# print(f_l)

# class Factorial:
#     def __init__(self, stop, start=1, step=1):
#         self.start = start
#         self.stop = stop
#         self.step = step

#     def __iter__(self):
#         return self

#     def __next__(self):
#         self.start += self.step
#         while self.start <= self.stop:
#             return self.factorial(self.start - self.step)
#         raise StopIteration

#     def factorial(self, num):
#         count = 1
#         for i in range(1, num + 1):
#             count = count * i
#         return count


# if __name__ == '__main__':
#     fact = Factorial(4)
#     for n in fact:
#         print(n)

def __init__(self, start, stop=None, step=None):
    if stop is None:
        self.start = 1
        self.stop = start
    else:
        self.start = start
        self.stop = stop
    self.step = step if step else 1


class Factorial:
    def __init__(self, *args):
        self.start, self.stop, self.step = 1, 1, 1
        if len(args) == 1:
            self.stop = args[0]
        elif len(args) == 2:
            self.start = args[0]
            self.stop = args[1]
        elif len(args) == 3:
            self.start = args[0]
            self.stop = args[1]
            self.step = args[2]

    def __iter__(self):
        return self

    def __next__(self):
        self.start += self.step
        while self.start <= self.stop:
            return self.factorial(self.start - self.step)
        raise StopIteration

    def factorial(self, num):
        count = 1
        for i in range(1, num + 1):
            count = count * i
        return count


if __name__ == '__main__':
    fact = Factorial(4)
    for n in fact:
        print(n)