# home-git-les2
- git diff 8897d25 d014a17 62d35c
- git blame index.html
- git revert 1c9f8b89
- git blame index.html
- git revert 62d35c31
- git blame index.html
- git revert 13a902e4
- git blame index.html
- git reset --soft HEAD@\{3\}
- git restore
- git reset --mixed HEAD@\{4\}
- git restore
- git reset --hard HEAD@\{6\}
- git blame index.html
# Изменение
![изменение](1.png)
# отмена изменений
![отмена](2.png)
